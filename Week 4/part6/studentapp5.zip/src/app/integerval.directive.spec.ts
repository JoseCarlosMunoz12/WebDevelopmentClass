import { IntegervalDirective } from './integerval.directive';

describe('IntegervalDirective', () => {
  it('should create an instance', () => {
    const directive = new IntegervalDirective();
    expect(directive).toBeTruthy();
  });
});
