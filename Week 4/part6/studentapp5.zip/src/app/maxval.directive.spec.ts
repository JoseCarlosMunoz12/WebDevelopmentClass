import { MaxvalDirective } from './maxval.directive';

describe('MaxvalDirective', () => {
  it('should create an instance', () => {
    const directive = new MaxvalDirective();
    expect(directive).toBeTruthy();
  });
});
