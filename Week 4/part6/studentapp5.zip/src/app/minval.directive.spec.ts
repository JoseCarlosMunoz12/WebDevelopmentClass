import { MinvalDirective } from './minval.directive';

describe('MinvalDirective', () => {
  it('should create an instance', () => {
    const directive = new MinvalDirective();
    expect(directive).toBeTruthy();
  });
});
