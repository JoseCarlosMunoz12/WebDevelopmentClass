package edu.roosevelt.mruth.studentsystemfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsystemfinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsystemfinalApplication.class, args);
	}

}
