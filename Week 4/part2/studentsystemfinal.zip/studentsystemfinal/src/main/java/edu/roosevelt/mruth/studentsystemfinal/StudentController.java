/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.roosevelt.mruth.studentsystemfinal;

import java.util.ArrayList;
import java.util.Random;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Student Controller
 * 
 * CRUD -> Create, Read, Update, Delete
 * CRUD ->  POST  , GET,  PUT,    DELETE 
 * @author mruth
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class StudentController {
    
    private Logger logger = LoggerFactory.getLogger(StudentController.class);
    
    private ArrayList<Student> roster = new ArrayList();
    //constructor for our student controller
    public StudentController() {
        //need random
        Random random = new Random();
        //list of arrays for init purposes
        String[] fnames = {"Alice","Bob","Carol","David","Elizabeth"};
        String[] lnames = {"Winston","Darnold","Brady","Mariota"};
        String[] majors = {"CS","IT","CY","DA"};
        logger.debug("Going to create students:");
        //create the list
        for (int i=0; i<25; i++) {
            //create student
            Student s = new Student();
            s.setSID(random.nextInt(89999) + 10000);
            String name = lnames[random.nextInt(lnames.length)] + ", ";
            name = name + fnames[random.nextInt(fnames.length)];
            s.setName(name);
            s.setMajor(majors[random.nextInt(majors.length)]);
            s.setGPA(random.nextDouble() * 4.0);
            s.setHours(random.nextInt(120));
            logger.debug(s.toString());
            //add to list
            roster.add(s);
        }        
    }
    
    
    
    /**
     * List all students
     * @return roster of students
     */
    @GetMapping("/students")
    public ArrayList<Student> getStudents() {
        logger.debug("GetAllStudents: " + roster.size());
        return roster;        
    }
    
    
    /**
     * Get a specific student
     * @param sid SID of the student we're interested in
     * @return student we're interested in OR null if student !found
     */
    
    @GetMapping("/students/{sid}")
    public ResponseEntity<Student> getStudent(@PathVariable("sid") int sid) {
        logger.debug("GetStudent: " + sid);
        //fake student
        Student fake = new Student();
        fake.setSID(sid);
        //is it there?
        if (roster.contains(fake)) {
            logger.debug("GetStudent: " + sid + " -> already exists");
            //it's there, so return it
            Student real = roster.get(roster.indexOf(fake));
            logger.debug("GetStudent: " + sid + " S:" + real.toString());
            return new ResponseEntity(real, HttpStatus.OK);
            //return ResponseEntity.ok().body(real);
        } else {
            logger.debug("GetStudent: " + sid + " -> doesn't exist -> 404");
            //it's not there, return null
            return new ResponseEntity(null, HttpStatus.NOT_FOUND);
        }
        
    }
    
    @PostMapping(value = "/students", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Student> addStudent(@RequestBody @Valid final Student student) {
        logger.debug("AddStudent: " + student.toString());
        //is student already there?
        if (roster.contains(student)) {
            logger.debug("AddStudent: " + student.toString() + " already there");
            //already there, report
            return new ResponseEntity(student, HttpStatus.FOUND);
        } else {
            //not there, add and report
            roster.add(student);
            logger.debug("AddStudent: " + student.toString() + " added!");
            return new ResponseEntity(student, HttpStatus.OK);
        }
        
        
    }
    
    @PutMapping(value = "/students", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Student> editStudent(@RequestBody @Valid final Student student) {
        logger.debug("EditStudent: " + student.toString());
        //is it there?
        if (roster.contains(student)) {
            logger.debug("EditStudent: " + student.toString() + " is there");
            //it's there, so return it
            Student real = roster.get(roster.indexOf(student));
            //now edit the real student
            if (student.getGPA() >= 0 && student.getGPA() <= 4.0) {
                real.setGPA(student.getGPA());
            }
            if (student.getName() != null) {
                real.setName(student.getName());
            }
            
            if (student.getHours() >= 0) {
                real.setHours(student.getHours());
            }
            
            if (student.getMajor() != null) {
                real.setMajor(student.getMajor());
            }           
            return new ResponseEntity(student, HttpStatus.OK);
        } else {
            logger.debug("EditStudent: " + student.getSID() + " Not found");
            //it's not there, return student
            return new ResponseEntity(student, HttpStatus.NOT_FOUND);
        }
        
    }
    
    @DeleteMapping("/students/{sid}")
    public ResponseEntity<Student> deleteStudent(@PathVariable("sid") int sid) {
        logger.debug("DeleteStudent: " + sid);
        //fake student
        Student fake = new Student();
        fake.setSID(sid);
        //is it there?
        if (roster.contains(fake)) {
             logger.debug("DeleteStudent: " + sid + " is there, for now");
            //it's there, so remove it
            Student real = roster.get(roster.indexOf(fake));
            roster.remove(fake);
            return new ResponseEntity(real, HttpStatus.OK);
            //return ResponseEntity.ok().body(real);
        } else {
            //it's not there, return null
            logger.debug("DeleteStudent: " + sid + " is not there -> 404");
            return new ResponseEntity(null, HttpStatus.NOT_FOUND);
        }
        
    }
    
    
}
