/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.roosevelt.mruth.studentsystemfinal;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Range;

/**
 *
 * @author mruth
 */
public class Student {
    @NotBlank(message = "Name cannot be blank")
    @Size(max=30, message = "Name must be no more than 30 characters long")
    private String name;
    @Min(value = 10000, message = "SID must be a five digit number")
    @Max(value = 99999, message = "SID must be a five digit number")
    private int SID;
    
    @Range(min=0, max=4, message = "GPA must be between 0.0 and 4.0")
    private double GPA;
    @NotBlank(message = "Major cannot be blank")
    @Size(max=30, message = "Major must be no more than 30 characters long")
    private String major;

    @PositiveOrZero(message = "Hours must be equal or greater than 0")
    private int hours;

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    @Override
    public String toString() {
        return "Student{" + "name=" + name + ", SID=" + SID + ", GPA=" + GPA + ", major=" + major + ", hours=" + hours + '}';
    }
    
    
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.SID;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        return this.SID == other.SID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSID() {
        return SID;
    }

    public void setSID(int SID) {
        this.SID = SID;
    }

    public double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }
    
}
