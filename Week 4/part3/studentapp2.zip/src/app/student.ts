export class Student {
    sid: number;
    name: string;
    major: string;
    gpa: number;
    hours: number;
    
}
